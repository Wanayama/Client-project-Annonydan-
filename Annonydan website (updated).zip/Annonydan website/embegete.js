ScrollReveal({
    reset: true,
    distance: '80px',
    duration: 2000,
    delay: 200
});
ScrollReveal().reveal('.form-box', {origin: 'top'});
ScrollReveal().reveal('.htext', {origin: 'left'});
ScrollReveal().reveal('.htext p', {origin: 'bottom'});

